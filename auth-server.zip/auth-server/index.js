// This is the main file

// Test to see if node works and we can execute this .js
//console.log('Hola desde Node');

const express = require('express');
const cors = require('cors');
const { dbConnection } = require('./db/config');
require('dotenv').config();

//console.log(process.env);

//Crear el servidor/aplicacion de express
const app = express();

//Base de datos (ahora falla porque no esta la URL correcta)
//dbConnection();

// Directorio publico
app.use( express.static('public') );

//GET v.1
// app.get('/', ( req, res ) => {
//     //console.log('Peticion en el /');

//     //Por si queremos devolver otro status (500, 300, ...)
//     //Por defecto es 200
//     //res.status(404).json({ ... });

//     res.json({
//         oh: true,
//         msg: 'Todo salio bien',
//         uid: 1394
//     });
// });

// CORS
app.use( cors() );

// Lectura y parseo del body
app.use ( express.json() );

// Rutas
// Esto es un middleware
app.use( '/api/auth', require('./routes/auth') );


//v.1
// app.listen( 4000, () => {
//     console.log(`Servidor corriendo en puerto ${ 4000 }`)
// });

app.listen( process.env.PORT, () => {
    console.log(`Servidor corriendo en puerto ${ process.env.PORT }`)
});