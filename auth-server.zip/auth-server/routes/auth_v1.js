const { Router } = require('express');
const { check } = require('express-validator');
const { crearUsuario, loginUsuario, revalidarToken } = require('../controllers/auth');

const router = Router();

// Crear un nuevo usuario
router.post( '/new', crearUsuario );

// Login de usuario
router.post( '/', loginUsuario );

// Validar y revalidar token
router.get( '/renew', revalidarToken )

// de esta manera lo exportamos para usarlo en otro lugar
module.exports = router;